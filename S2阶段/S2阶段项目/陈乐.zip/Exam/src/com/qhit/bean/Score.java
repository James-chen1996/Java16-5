package com.qhit.bean;

/**
 * Score entity. @author MyEclipse Persistence Tools
 */

public class Score implements java.io.Serializable {

	// Fields

	private Integer scoid;
	private Paper paper;
	private Student student;
	private String scostartTime;
	private String scofinishTime;
	private String scoscore;

	// Constructors

	/** default constructor */
	public Score() {
	}

	/** minimal constructor */
	public Score(Integer scoid, Student student) {
		this.scoid = scoid;
		this.student = student;
	}

	/** full constructor */
	public Score(Integer scoid, Paper paper, Student student,
			String scostartTime, String scofinishTime, String scoscore) {
		this.scoid = scoid;
		this.paper = paper;
		this.student = student;
		this.scostartTime = scostartTime;
		this.scofinishTime = scofinishTime;
		this.scoscore = scoscore;
	}

	// Property accessors

	public Integer getScoid() {
		return this.scoid;
	}

	public void setScoid(Integer scoid) {
		this.scoid = scoid;
	}

	public Paper getPaper() {
		return this.paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getScostartTime() {
		return this.scostartTime;
	}

	public void setScostartTime(String scostartTime) {
		this.scostartTime = scostartTime;
	}

	public String getScofinishTime() {
		return this.scofinishTime;
	}

	public void setScofinishTime(String scofinishTime) {
		this.scofinishTime = scofinishTime;
	}

	public String getScoscore() {
		return this.scoscore;
	}

	public void setScoscore(String scoscore) {
		this.scoscore = scoscore;
	}

}