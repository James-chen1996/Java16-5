package com.qhit.bean;

/**
 * StuPaperEq entity. @author MyEclipse Persistence Tools
 */

public class StuPaperEq implements java.io.Serializable {

	// Fields

	private Integer speid;
	private Student student;
	private Paper paper;
	private ExamQuestion examQuestion;
	private String stuanswer;

	// Constructors

	/** default constructor */
	public StuPaperEq() {
	}

	/** minimal constructor */
	public StuPaperEq(Integer speid, Student student) {
		this.speid = speid;
		this.student = student;
	}

	/** full constructor */
	public StuPaperEq(Integer speid, Student student, Paper paper,
			ExamQuestion examQuestion, String stuanswer) {
		this.speid = speid;
		this.student = student;
		this.paper = paper;
		this.examQuestion = examQuestion;
		this.stuanswer = stuanswer;
	}

	// Property accessors

	public Integer getSpeid() {
		return this.speid;
	}

	public void setSpeid(Integer speid) {
		this.speid = speid;
	}

	public Student getStudent() {
		return this.student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Paper getPaper() {
		return this.paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public ExamQuestion getExamQuestion() {
		return this.examQuestion;
	}

	public void setExamQuestion(ExamQuestion examQuestion) {
		this.examQuestion = examQuestion;
	}

	public String getStuanswer() {
		return this.stuanswer;
	}

	public void setStuanswer(String stuanswer) {
		this.stuanswer = stuanswer;
	}

}